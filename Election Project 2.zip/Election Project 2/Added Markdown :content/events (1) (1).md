
Events Calendar

<div class="eventCalendar">
  <iframe src="https://calendar.google.com/calendar/embed?src=8d3fc8l9g04n7r9im45fsn08ak%40group.calendar.google.com&ctz=America/New_York" style="border: 0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
</div>
<!-- end eventCalendar -->


Upcoming Events
<div class="eventCalendar agenda">
  <iframe src="https://calendar.google.com/calendar/embed?mode=AGENDA&amp;height=600&amp;wkst=1&amp;hl=en&amp;bgcolor=%23FFFFFF&amp;src=8d3fc8l9g04n7r9im45fsn08ak%40group.calendar.google.com&amp;color=%238D6F47&amp;ctz=America%2FNew_York" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
</div>

Featured Event

Third Presidential Debate
Date: Wednesday, October 19
Time: 9:00pm Eastern Standard Time

Watch the event live on the major TV networks including C-SPAN, ABC, CBS, FOX and NBC, CNN, Fox News and MSNBC, PBS NewsHour, Telemundo, and Univision, also there will be livestreams on YouTube, Twitter and Facebook Live.



Get Involved

Host a Rock The Vote event: https://www.rockthevote.com/get-involved/host-an-event/
Guide to Hosting Your Own Debate: http://www.debates.org/index.php?page=guide-to-hosting-your-own-debate

More Info

Commission on Presidential Debates: http://www.debates.org/
Debate Transcripts: http://www.debates.org/index.php?page=debate-transcripts
C-Span Video of Presidential Debates: https://www.c-span.org/presidentialDebate/
C-Span Coverage of the 2016 campaigns: https://www.c-span.org/series/?campaign2016
Get Election Reminders: https://www.rockthevote.com/get-informed/elections/reminders/
Twitter #Election2016: https://twitter.com/i/streams/stream/692841134482063360


Videos of Previous Debates

First Presidential Debate
  NBC: https://youtu.be/855Am6ovK7s
  CBS: https://www.youtube.com/playlist?list=PLEb3ThbkPrFZV-HePjrQVMHyHOeWaneX6
  ABC: https://youtu.be/GQFGTDFvMSc
  PBS: https://youtu.be/7BGYYaaLrTc
  FOX: https://youtu.be/ubp0CEbqW-U?t=54m35s
  
Second Presidential Debate
  NBC: https://youtu.be/FRlI2SQ0Ueg
  CBS: https://youtu.be/ooShpws3Dik
  ABC: https://youtu.be/h-gkBUbU_F4
  PBS: https://youtu.be/hqlB80QLr9M
  
  FOX: (general debate coverage) https://www.youtube.com/playlist?list=PLlTLHnxSVuIxC-yk6lYqsu4nW08qAE-jm
  
Vice Presidential Debate
  NBC: https://youtu.be/mVXqNcW_-HA
  CBS: https://www.youtube.com/playlist?list=PLEb3ThbkPrFYYnjSnwFgA2TG3P7gWIh1-
  ABC: https://youtu.be/9GfywoUoaok
  PBS: https://youtu.be/is8cx0q39bI
  


